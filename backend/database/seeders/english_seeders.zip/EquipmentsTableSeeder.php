<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EquipmentsTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('equipments')->insert([
            ['name' => 'Sword', 'equipment_type_id' => 1],
['name' => 'Helmet', 'equipment_type_id' => 2],
['name' => 'Ring of Strength', 'equipment_type_id' => 3],
['name' => 'Pickaxe', 'equipment_type_id' => 4]
        ]);
    }
}
