<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MaterialTypesTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('material_types')->insert([
            ['name' => 'Metal'],
['name' => 'Wood'],
['name' => 'Stone'],
['name' => 'Fabric']
        ]);
    }
}
