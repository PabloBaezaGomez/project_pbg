<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UsersTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('users')->insert([
            ['name' => 'Alice', 'email' => 'alice@example.com', 'password' => bcrypt('password')],
['name' => 'Bob', 'email' => 'bob@example.com', 'password' => bcrypt('password')],
['name' => 'Charlie', 'email' => 'charlie@example.com', 'password' => bcrypt('password')],
['name' => 'Diana', 'email' => 'diana@example.com', 'password' => bcrypt('password')]
        ]);
    }
}
