<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EquipmentTypesTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('equipment_types')->insert([
            ['name' => 'Weapon'],
['name' => 'Armor'],
['name' => 'Accessory'],
['name' => 'Tool']
        ]);
    }
}
