<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FoeTypesTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('foe_types')->insert([
            ['name' => 'Beast'],
['name' => 'Undead'],
['name' => 'Dragon'],
['name' => 'Elemental']
        ]);
    }
}
