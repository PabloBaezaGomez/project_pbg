<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MaterialsTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('materials')->insert([
            ['name' => 'Iron Ore', 'material_type_id' => 1],
['name' => 'Oak Wood', 'material_type_id' => 2],
['name' => 'Granite', 'material_type_id' => 3],
['name' => 'Silk', 'material_type_id' => 4]
        ]);
    }
}
