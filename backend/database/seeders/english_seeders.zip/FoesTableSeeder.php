<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FoesTableSeeder extends Seeder
{
    public function run()
    {
        DB::table('foes')->insert([
            ['name' => 'Wolf', 'foe_type_id' => 1],
['name' => 'Zombie', 'foe_type_id' => 2],
['name' => 'Fire Dragon', 'foe_type_id' => 3],
['name' => 'Water Elemental', 'foe_type_id' => 4]
        ]);
    }
}
